<?php
$servername = "localhost";
$test = "registeration";
$email=$_POST['email'];
$password=$_POST['password'];

$con = new mysqli("localhost","root","","test"); 
if($con->connect_error){
die("Failed to connect : ".$con->connect_error);

}
else{
$stmt=$con->prepare("select * from registeration where email=?");
$stmt->bind_param("s",$email);
$stmt->execute();
$stmt_result=$stmt->fetch_assoc();
if($data['password']===$password){
echo"<h2>Login successfully</h2>";
}
else{
echo"<h2>Invalid Email or password</h2>";
}
if($stmt_result->num>0){
$data=$stmt_result->get_result();

}
else{
echo"<h2>Invalid Email or password</h2>";
}

}