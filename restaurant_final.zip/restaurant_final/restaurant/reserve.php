<?php
	$form_name = $_POST['form_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$no_of_persons = $_POST['no_of_persons'];
	$datepicker = $_POST['datepicker'];
	$timepicker = $_POST['timepicker'];
    $preferred_food = $_POST['preferred_food'];
    $occasion = $_POST['occasion'];
       

	// Database connection
	$conn = new mysqli('localhost','root','','test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into reservation(form_name, email, phone, no_of_persons, datepicker, timepicker,preferred_food,occasion) values(?, ?, ?, ?, ?, ?,?,?)");
		$stmt->bind_param("ssssssss",$form_name, $email, $phone, $no_of_persons, $datepicker, $timepicker,$preferred_food,$occasion);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		header('location:index.html');
		$stmt->close();
		$conn->close();
	}
?>